<?php

namespace App\Services\Validations;

use App\Services\Validations\Validator;

class OrderValidation extends Validator
{
	protected $rules = [];
}