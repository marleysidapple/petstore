Message from Contact Form<hr />
Name: {{ $name }}<br />
Email: {{ $email }}<br />
Number: {{ $number }}<br />
Name of Inquiry: {{ $name_of_inquiry }}<br /><br /><br />
Message: {{ $description }}
