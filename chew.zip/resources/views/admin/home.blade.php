@extends('layouts.admin', ['pageBreadcrumb' => 'Dashboard'])

@section('content')
<div class="content-top">
    <div class="col-md-12 ">
        <div class="content-top-1">
            <div class="col-md-12 top-content">
                <h2>Welcome to RDC</h2>
            </div>
            <div class="clearfix"> </div>
        </div>
		<div class="content-top-1">
		    <div class="col-md-12 top-content">
			</div>
		</div>
	</div>
</div>
@endsection