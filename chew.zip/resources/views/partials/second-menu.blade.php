<section class="second-menu">
    <ul>
        <li>
            <a href="{{url('/')}}">Home</a>
        </li>
        <li>
            <a href="{{url('about-us')}}">About Us</a>
        </li>
        <li>
            <a href="{{url('our-products')}}">Our Products</a>
        </li>
       
        <li>
            <a href="{{url('stores-search')}}">Find US</a>
        </li>
        <li>
            <a href="{{url('contact-us')}}">Contact Us</a>
        </li>
        <li>
            <a href="{{url('login')}}">Retailed Sign In</a>
        </li>
    </ul>
    <span class="fa fa-3x fa-close"></span>
</section>