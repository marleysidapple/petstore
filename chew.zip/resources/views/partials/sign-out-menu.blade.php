<section class="second-menu">
    <ul class="first">
        <li><a href="index.php">Home</a></li>
        <li><a href="pricing.php">Pricing</a></li>
        <li><a href="<?= route('stores-search') ?>">Find US</a></li>
        <li><a href="order.php">Place Order</a></li> 
        <li><a href="#">Account <span class="caret"></span></a>
           	<ul class="account-menu">
             	<li><a href="account.php">Edit Profile</a></li>
              	<li><a href="forms.php">forms</a></li>
              	<li><a href="shipping.php">Shipping & Garauntee</a></li>
              	<li><a href="manage-store.php">Manage Store</a></li>
              	<li><a href="manage-retail.php">Manage Retailer Contact</a></li>
            </ul> 
        </li>   
        <li><a href="index.php">Sign Out</a></li>
    </ul>
    <span class="fa fa-3x fa-close"></span>
</section>